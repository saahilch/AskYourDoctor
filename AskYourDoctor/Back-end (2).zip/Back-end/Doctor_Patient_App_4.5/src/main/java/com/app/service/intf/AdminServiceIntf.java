package com.app.service.intf;

import com.app.entity.modal.Admin;

import java.util.List;

public interface AdminServiceIntf {

	//get admin list
	List<Admin> getListOfAdmin();
	
}

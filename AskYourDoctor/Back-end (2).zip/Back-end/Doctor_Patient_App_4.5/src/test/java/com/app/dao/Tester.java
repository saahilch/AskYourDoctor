package com.app.dao;

public class Tester {
	public Tester() {
		System.out.println("hii");
	}
}
